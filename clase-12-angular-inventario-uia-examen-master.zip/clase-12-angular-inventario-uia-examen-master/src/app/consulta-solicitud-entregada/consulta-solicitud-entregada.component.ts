import { Component } from '@angular/core';

@Component({
  selector: 'app-consulta-solicitud-entregada',
  templateUrl: './consulta-solicitud-entregada.component.html',
  styleUrls: ['./consulta-solicitud-entregada.component.css']
})
export class ConsultaSolicitudEntregadaComponent {

}
